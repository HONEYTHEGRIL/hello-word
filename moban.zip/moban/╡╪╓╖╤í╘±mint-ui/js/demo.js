var city_name=""
const vm=new Vue({
    el:".app",
    data:{
        pop:false,
        city_name:'北京-北京',
        slots: [
            {
              flex: 1,
              values: [],
              className: 'slot1',
              textAlign: 'right'
            }, {
              divider: true,
              content: '-',
              className: 'slot2'
            }, {
              flex: 1,
              values: [],
              className: 'slot3',
              textAlign: 'left'
            }
          ]
    },
    created:function(){
        this.slots[0].values=citys.provinces;
        this.slots[2].values=citys.provinces[0].cities;
    },
    methods:{
        // 控制弹窗出现
        choseAddress:function(){
            this.pop=true;
        },
        // 确认或取消选择
        selectAddress:function(index){
            if(index){
                this.pop=false;
                this.city_name=city_name
            }else{
                this.pop=false;
            }
        },
        // 改变地址时
        onValuesChange:function(picker,values){
            if(picker.getSlotValue(0)){
                this.slots[2].values=picker.getSlotValue(0).cities;
                if(picker.getSlotValue(1)){
                    city_name=picker.getSlotValue(0).name+'-'+picker.getSlotValue(1).name
                }
                
            }
        }
    }
})
const vm=new Vue({
    el:'.app',
    data:{
       
      
        share_show:false,
       
        //分享渠道
        share_list:[
            {
                icon:'images/wechart_icon.png',
                text:'微信'
            },
            {
                icon:'images/friends_icon.png',
                text:'朋友圈'
            },
            {
                icon:'images/qq_icon.png',
                text:'QQ好友'
            },
            {
                icon:'images/space_icon.png',
                text:'空间'
            }
        ],
        
    },
    methods:{
       
        // 分享
        shareBtn:function(){
            this.share_show=true
        },

        closeShare:function(){
            console.log(1)
            this.share_show=false
        }
    }
})
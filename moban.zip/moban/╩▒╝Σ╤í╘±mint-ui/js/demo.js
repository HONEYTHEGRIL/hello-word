var city_name=""
const vm=new Vue({
    el:".app",
    data:{
        year:'2019',
        mounth:'04',
        dateVal:""
    },
    created:function(){
        if (this.selectedValue) {
            this.dateVal = this.selectedValue
        } else {
            this.dateVal = new Date()
        }
    },
    methods:{
        chooseTime:function(){
            document.getElementsByClassName('picker-slot-center')[2].style.display="none";
            this.$refs.picker.open()
        },
        handleConfirm:function(value){
            this.year=value.getFullYear();
            var mounth=value.getMonth()+1
            if(mounth<10){
                mounth="0"+mounth
            }
            this.mounth=mounth
        }
        
    }
})
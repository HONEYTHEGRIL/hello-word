var vm = new Vue({
  el: ".vueBox",
  data: {
    points: ['','','',''],
    lists: ['','','']
  },
  created: function () {

  },
  methods: {
    tabSelect: function (index) {
      this.tabIndex = index
    }
  }
});

var timer = null;
var flag =false;
var vm = new Vue({
    el: ".vueBox",
    data: {
        ico_clear:"images/ico_clear.png",
        isFull:false,
        readonly:true,
        disabled:true,
        ver_tel:'',
        ver_code:'',
        auth_time: 60,
        auth_text: '获取验证码',
    },
    created: function () {

    },
    methods: {
        verTel() {
			if(this.ver_tel.length>=11){
				 this.isFull=true;
			}
           

        },
        getCode() {
            if(this.isFull){
                this.timeChange();
                this.readonly=false
            }
        },
        verCode() {
            this.disabled=false
        },
        timeChange(){
			if(flag) {return false}
			flag =true
			this.auth_text = '重发('+  (this.auth_time >= 10 ? this.auth_time : '0' + this.auth_time) + 's)';
            timer = setInterval(res => {
                this.auth_time--;
                this.auth_text = '重发('+  (this.auth_time >= 10 ? this.auth_time : '0' + this.auth_time) + 's)';
                if (this.auth_time <= 0) {
                    if (timer != null) {
                        clearInterval(timer);
                        this.auth_text = "重新获取";
						flag =false
                    }
                }
                console.log( this.auth_time);
            }, 1000);
        },


    }
});
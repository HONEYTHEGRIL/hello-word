const vm=new Vue({
    el:"#app",
    data:{
        lang:1,//0 阿语  1英语
        cur_active:0,
        pop:false,
        //当前页面高度
        top:0,
        //当前页面高度(rem单位下)
        top_num:0,
        tap_dot:'./images/tap_dot.png',
        active_time:'./images/active_time.png',
        active_time_a:'./images/active_time_a.png',
        rank_frist_head:'./images/rank_frist_head.png',
        rank_frist_bg:'./images/rank_frist_bg.png',
        rank_second_head:'./images/rank_second_head.png',
        rank_second_bg:'./images/rank_second_bg.png',
        rank_third_head:'./images/rank_third_head.png',
        rank_third_bg:'./images/rank_third_bg.png',
        drop_down:'./images/drop_down.png',
        heart:'./images/heart.png',
        left_arrow:'./images/left_arrow.png',
        right_arrow:'./images/right_arrow.png',
        close_ico:'./images/close_ico.png',
        //男女、财富榜排名
        rank_list:[
            {
                ranking_list:[
                    {
                        rank:1,
                        img_url:'',
                        name:'阿里阿里阿里',
                        integral:10000,
                    },
                    {
                        rank:2,
                        img_url:'',
                        name:'阿里阿里阿里',
                        integral:10000,
                    },
                    {
                        rank:3,
                        img_url:'',
                        name:'阿里阿',
                        integral:10000,
                    },
                    {
                        rank:4,
                        img_url:'',
                        name:'阿里阿里阿',
                        integral:10000,
                    },
                    {
                        rank:5,
                        img_url:'',
                        name:'阿里阿里阿里',
                        integral:10000,
                    },
                ],
            },
            {
                ranking_list:[
                    {
                        rank:1,
                        img_url:'',
                        name:'阿里',
                        integral:10000,
                    },
                    {
                        rank:2,
                        img_url:'',
                        name:'阿里阿里阿里',
                        integral:10000,
                    },
                    {
                        rank:3,
                        img_url:'',
                        name:'阿里阿',
                        integral:10000,
                    },
                    {
                        rank:4,
                        img_url:'',
                        name:'阿里阿里阿',
                        integral:10000,
                    },
                    {
                        rank:5,
                        img_url:'',
                        name:'阿里阿里阿里',
                        integral:10000,
                    },
                ],
            },
            {
                ranking_list:[
                    {
                        rank:1,
                        img_url:'',
                        name:'阿里阿里',
                        integral:10000,
                    },
                    {
                        rank:2,
                        img_url:'',
                        name:'阿里阿里阿里',
                        integral:10000,
                    },
                    {
                        rank:3,
                        img_url:'',
                        name:'阿里阿',
                        integral:10000,
                    },
                    {
                        rank:4,
                        img_url:'',
                        name:'阿里阿里阿',
                        integral:10000,
                    },
                    {
                        rank:5,
                        img_url:'',
                        name:'阿里阿里阿里',
                        integral:10000,
                    },
                ],
            },
           
         ],
        //  房间榜排名
        room_ranking_list:[
            {
                rank:1,
                img_url:'',
                name:'阿里阿里阿里',
                integral:10000,
            },
            {
                rank:2,
                img_url:'',
                name:'阿里阿里阿里',
                integral:10000,
            },
            {
                rank:3,
                img_url:'',
                name:'阿里阿',
                integral:10000,
            },
            {
                rank:4,
                img_url:'',
                name:'阿里阿里阿',
                integral:10000,
            },
            {
                rank:5,
                img_url:'',
                name:'阿里阿里阿里',
                integral:10000,
            },
        ],
        // cp 排行
        cp_ranking_list:[
            {
                rank:1,
                boy_img_url:'',
                gril_img_url:'',
                boy_name:'阿里阿里阿里',
                gril_name:'娜娜',
                integral:10000,
            },
            {
                rank:2,
                boy_img_url:'',
                gril_img_url:'',
                boy_name:'阿里阿里阿里',
                gril_name:'娜娜',
                integral:10000,
            },
            {
                rank:3,
                boy_img_url:'',
                gril_img_url:'',
                boy_name:'阿里阿里阿里',
                gril_name:'娜娜',
                integral:10000,
            },
            {
                rank:4,
                boy_img_url:'',
                gril_img_url:'',
                boy_name:'阿里阿里阿里',
                gril_name:'娜娜',
                integral:10000,
            },
            {
                rank:5,
                boy_img_url:'',
                gril_img_url:'',
                boy_name:'阿里阿里阿里',
                gril_name:'娜娜',
                integral:10000,
            },
        ],
        // 四周年奖励
        anniversary_list:[
            {
                img_url:'',
                name:'礼物'
            },
            {
                img_url:'',
                name:'礼物礼物礼物礼物礼物礼物'
            },
            {
                img_url:'',
                name:'礼物礼物礼物礼物礼物礼物'
            },
            {
                img_url:'',
                name:'礼物礼物礼物礼物礼物礼物'
            },
        ],
        // 奖励弹窗
        reward_list:[
            // 男生榜
            {
                rank_title:[
                    {
                        gift_list:[
                            {
                                img_url:'',
                                name:'礼物'
                            },
                            {
                                img_url:'',
                                name:'礼物'
                            },
                            {
                                img_url:'',
                                name:'礼物'
                            },
                            {
                                img_url:'',
                                name:'礼物'
                            },
                        ],
                    },
                    {
                        gift_list:[
                            {
                                img_url:'',
                                name:'礼物'
                            },
                            {
                                img_url:'',
                                name:'礼物'
                            },
                            {
                                img_url:'',
                                name:'礼物'
                            },
                            
                        ],
                    },
                    {
                        gift_list:[
                            {
                                img_url:'',
                                name:'礼物'
                            },
                            {
                                img_url:'',
                                name:'礼物'
                            },
                            {
                                img_url:'',
                                name:'礼物'
                            },
                           
                        ],
                    }
                ],
            },
            // 女生榜
            {
                rank_title:[
                    {
                        title:'First Winner ',
                        gift_list:[
                            {
                                img_url:'',
                                name:'礼物'
                            },
                            {
                                img_url:'',
                                name:'礼物'
                            },
                            {
                                img_url:'',
                                name:'礼物'
                            },
                            {
                                img_url:'',
                                name:'礼物'
                            },
                        ],
                    },
                    {
                        title:'Second Winner ',
                        gift_list:[
                            {
                                img_url:'',
                                name:'礼物'
                            },
                            {
                                img_url:'',
                                name:'礼物'
                            },
                            {
                                img_url:'',
                                name:'礼物'
                            },
                            
                        ],
                    },
                    {
                        title:'Third Winner ',
                        gift_list:[
                            {
                                img_url:'',
                                name:'礼物'
                            },
                            {
                                img_url:'',
                                name:'礼物'
                            },
                            {
                                img_url:'',
                                name:'礼物'
                            },
                           
                        ],
                    }
                ],
            },
            // 财富榜
            {
                rank_title:[
                    {
                        title:'First Winner ',
                        gift_list:[
                            {
                                img_url:'',
                                name:'礼物'
                            },
                            {
                                img_url:'',
                                name:'礼物'
                            },
                            {
                                img_url:'',
                                name:'礼物'
                            },
                           
                        ],
                    },
                    {
                        title:'Second Winner ',
                        gift_list:[
                            {
                                img_url:'',
                                name:'礼物'
                            },
                            {
                                img_url:'',
                                name:'礼物'
                            },
                            
                            
                        ],
                    },
                    {
                        title:'Third Winner ',
                        gift_list:[
                            {
                                img_url:'',
                                name:'礼物'
                            },
                            {
                                img_url:'',
                                name:'礼物'
                            },
                           
                           
                        ],
                    }
                ],
            },
            // 房间榜
            {
                rank_title:[
                    {
                        title:'First Winner ',
                        gift_list:[
                            {
                                img_url:'',
                                name:'礼物'
                            },
                            {
                                img_url:'',
                                name:'礼物'
                            },
                            {
                                img_url:'',
                                name:'礼物'
                            },
                           
                        ],
                    },
                    {
                        title:'Second Winner ',
                        gift_list:[
                            {
                                img_url:'',
                                name:'礼物'
                            },
                            {
                                img_url:'',
                                name:'礼物'
                            },
                            
                            
                        ],
                    },
                    {
                        title:'Third Winner ',
                        gift_list:[
                            {
                                img_url:'',
                                name:'礼物'
                            },
                            {
                                img_url:'',
                                name:'礼物'
                            },
                           
                        ],
                    }
                ],
            },
            // cp榜
            {
                rank_title:[
                    {
                        title:'First Winner ',
                        gift_list:[
                            {
                                img_url:'',
                                name:'礼物'
                            },
                            {
                                img_url:'',
                                name:'礼物'
                            },
                            {
                                img_url:'',
                                name:'礼物'
                            },
                          
                        ],
                    },
                    {
                        title:'Second Winner ',
                        gift_list:[
                            {
                                img_url:'',
                                name:'礼物'
                            },
                            {
                                img_url:'',
                                name:'礼物'
                            },
                            {
                                img_url:'',
                                name:'礼物'
                            },
                            
                        ],
                    },
                    {
                        title:'Third Winner ',
                        gift_list:[
                            {
                                img_url:'',
                                name:'礼物'
                            },
                            {
                                img_url:'',
                                name:'礼物'
                            },
                            {
                                img_url:'',
                                name:'礼物'
                            },
                           
                        ],
                    }
                ],
            },
        ],
        list:[
            // 阿语
            {
                title:'كرنفال الاحتفال بالذكري السنوية',
                 // 切换
                 tap_list:[
                    'قائمة السحر للرجال',
                    'قائمة السحر للنساء',
                    'قائمة سوبر ثروة',
                    'قائمة سوبر غرفة',
                    'قائمة CP',
                ],
                reward:'مكافأة',
                rules:'قواعد النشاط :',
                anniversary_gift:'أيها المستخدمون الأعزاء، مرحبا بكم! سنقدم أربع هدايا تذكارية لهذه الذكرى السنوية.',
                // 奖励弹窗标题
                reward_title:[
                    "الفائز الأول ",
                    "الفائز الثانى ",
                    "الفائز الثالث ",
                ],
                // 规则列表
                rules_list:[
                    // 男生榜
                    {
                        list:[
                            "١. وقت النشاط: ١١:٠٠صباحا  أول يوليو عام ٢٠١٩- ٢٣:٥٩ مساء اليوم ال٣١ من يوليو عام ٢٠١٩",
                            " ٢. في فترة النشاط، سيحصل المستخدم على إطارة الميكروفون التذكارية (٣ أيام) من خلال إهداء أي هدية من أربع هدايا تذكارية سنوية للآخرين",
                            "٣. هذه القائمة للمستخدمين الذكور فقط.",
                            "٤. بعد انتهاء النشاط، ستحصل الأوائل الثلاثة في القائمة على وسام شخصي (التصميم الخاص) والمكافآت الأخرى. (وسام شخصي: يمكن للفائزين اختيار خمسة أحرف من ٢٦ حرفا إنجليزيا و١٠ أرقام عربية كالكتابات الخاصة)",
                            " ٥. في فترة النشاط، سيزيد قيمة سحره من خلال استلام هدايا تذكارية، ١ عملة ذهبية = ١نقطة سحر، يحصل نقاطا أعلى، سيصبح مرتبة في القائمة أعلى.",
                            "٦.سيتم توزيع المكافآت للنشاط في غضون يوم إلى ثلاثة أيام بعد انتهاء النشاط.",
                        ],
                    },
                    // 女生榜
                    {
                        list:[
                            "١. وقت النشاط: ١١:٠٠صباحا  أول يوليو عام ٢٠١٩- ٢٣:٥٩ مساء اليوم ال٣١ من يوليو عام ٢٠١٩",
                            " ٢. في فترة النشاط، سيحصل المستخدم على إطارة الميكروفون التذكارية (٣ أيام) من خلال إهداء أي هدية من أربع هدايا تذكارية سنوية للآخرين",
                            " ٣.هذه القائمة للمستخدمين الإناث فقط.",
                            "٤. بعد انتهاء النشاط، ستحصل الأوائل الثلاثة في القائمة على وسام شخصي (التصميم الخاص) والمكافآت الأخرى. (وسام شخصي: يمكن للفائزين اختيار خمسة أحرف من ٢٦ حرفا إنجليزيا و١٠ أرقام عربية كالكتابات الخاصة)",
                            " ٥. في فترة النشاط، سيزيد قيمة سحره من خلال استلام هدايا تذكارية، ١ عملة ذهبية = ١نقطة سحر، يحصل نقاطا أعلى، سيصبح مرتبة في القائمة أعلى.",
                            "٦.سيتم توزيع المكافآت للنشاط في غضون يوم إلى ثلاثة أيام بعد انتهاء النشاط.",
                        ],
                    },
                    // 财富榜
                    {
                        list:[
                            "١. وقت النشاط: ١١:٠٠صباحا  أول يوليو عام ٢٠١٩- ٢٣:٥٩ مساء اليوم ال٣١ من يوليو عام ٢٠١٩",
                            " ٢. في فترة النشاط، سيحصل المستخدم على إطارة الميكروفون التذكارية (٣ أيام) من خلال إهداء أي هدية من أربع هدايا تذكارية سنوية للآخرين",
                            "٤. بعد انتهاء النشاط، ستحصل الأوائل الثلاثة في القائمة على وسام شخصي (التصميم الخاص) والمكافآت الأخرى. (وسام شخصي: يمكن للفائزين اختيار خمسة أحرف من ٢٦ حرفا إنجليزيا و١٠ أرقام عربية كالكتابات الخاصة)",
                            " ٥. في فترة النشاط، سيزيد قيمة سحره من خلال استلام هدايا تذكارية، ١ عملة ذهبية = ١نقطة سحر، يحصل نقاطا أعلى، سيصبح مرتبة في القائمة أعلى.",
                            "٦.سيتم توزيع المكافآت للنشاط في غضون يوم إلى ثلاثة أيام بعد انتهاء النشاط.",
                            " سوف يتواصل مسئول خدمة العملاء بعد انتهاء النشاط مع المستخدم حتى يستلم الجائزة ، إذا لم يصدر من المستخدم أى رد خلال شهر واحد ، سيعتبر هذا بمثابة تنازل منه عن الهدية المقدمة له.",
                            "إذا تم اكتشاف استخدام أسلوب منافى لقوانين البرنامج لكسب الجوائز، سيتم إلغاء حق المشاركة فى النشاط، و لن يتم إرسال أى مكافآت .",
                        ],
                    },
                    // 房间榜
                    {
                        list:[
                            "١. وقت النشاط: ١١:٠٠صباحا  أول يوليو عام ٢٠١٩- ٢٣:٥٩ مساء اليوم ال٣١ من يوليو عام ٢٠١٩",
                            "٢. في فترة النشاط، إن إهداء أي هدية في الغرفة سيزيد قيمة الغرفة، ١ عملة ذهبية = ١ قيمة ، يحصل قيمة أعلى، سيصبح مرتبة في قائمة الغرف أعلى ",
                            "٦.سيتم توزيع المكافآت للنشاط في غضون يوم إلى ثلاثة أيام بعد انتهاء النشاط.",
                            " سوف يتواصل مسئول خدمة العملاء بعد انتهاء النشاط مع المستخدم حتى يستلم الجائزة ، إذا لم يصدر من المستخدم أى رد خلال شهر واحد ، سيعتبر هذا بمثابة تنازل منه عن الهدية المقدمة له.",
                            "إذا تم اكتشاف استخدام أسلوب منافى لقوانين البرنامج لكسب الجوائز، سيتم إلغاء حق المشاركة فى النشاط، و لن يتم إرسال أى مكافآت .",
                        ],
                    },
                     // cp榜
                    {
                        list:[
                            "١. وقت النشاط: ١١:٠٠صباحا  أول يوليو عام ٢٠١٩- ٢٣:٥٩ مساء اليوم ال٣١ من يوليو عام ٢٠١٩",
                            " ٢. في فترة النشاط، سيكون المستخدم \"cp\" مع الذي يهدي أكثر نقطة ذهبية من هدايا بشكل متبادل، ١ نقطة ذهبية = ١ قيمة \"CP\".",
                            "٣. وسوف تصنف قائمة CP وفقا لمجموع العملات الذهبية من الهدايا (التحويل إلى قيمة cp) التي يهديها المستخدمان بشكل متبادلة، يحصل عدد مجموع العملات الذهبية أكثر، سيصبح مرتبة في القائمة أعلى .",
                            "سوف يتواصل مسئول خدمة العملاء بعد انتهاء النشاط مع المستخدم حتى يستلم الجائزة ، إذا لم يصدر من المستخدم أى رد خلال شهر واحد ، سيعتبر هذا بمثابة تنازل منه عن الهدية المقدمة له.",
                            "إذا تم اكتشاف استخدام أسلوب منافى لقوانين البرنامج لكسب الجوائز، سيتم إلغاء حق المشاركة فى النشاط، و لن يتم إرسال أى مكافآت .",
                        ],
                    }
                ],
               
                anniversary_rewads:'٢. في فترة النشاط، سيحصل المستخدم على إطارة الميكروفون التذكارية (٣ أيام) من خلال إهداء أي هدية من أربع هدايا تذكارية سنوية للآخرين',
                copyright:'تخضع الحقوق النهائية لهذا النشاط للمنصة الرسمية لتطبيق هيا',
                apple_copyright:'شركة أبل ليست شركة راعية، ولم تشارك بأي شكل من الاشكال في اي مسابقة، ولم تحصل علي هدايا من اي نشاط',
            },
            // 英语
            {
                title:'Anniversary Celebration Carnival.Fight!',
                // 切换
                tap_list:[
                    'List of Charm for Male',
                    'List of Charm for Female',
                    'Super Rich List',
                    'Super Room List',
                    'The CP List',
                ],
                reward:'Reward',
                rules:'Activity Guide',
                anniversary_gift:'Dear users, we will release four anniversary gifts for this anniversary.',
                // 奖励弹窗标题
                reward_title:[
                    "First Winner ",
                    "Second Winner ",
                    "Third Winner ",
                ],
                // 规则列表
                rules_list:[
                    // 男生榜
                    {
                        list:[
                            "Activity duration: 11:00 a.m., July 1, 2019 - 23:59 p.m., July 31, 2019",
                            "During the event, you can get one anniversary specific mic frame (3 days) if you send others any of the four anniversary gifts.",
                            "This list is for male users only.",
                            "After the event, the top three on the list will receive personalized medal (customized) and other rich rewards. (for personalized medal: winners can choose five characters from 26 English letters and 10 Arabic numerals as their own custom-made copywriting)",
                            "During the event, users will increase their charm value by receiving anniversary gifts. 1 gold coin = 1 charm value, and the higher the charm value is, the higher the ranking will be.",
                            "The rewards will be distributed within 1-3 days after the activity.",
                        ],
                    },
                    // 女生榜
                    {
                        list:[
                            "Activity duration: 11:00 a.m., July 1, 2019 - 23:59 p.m., July 31, 2019",
                            "During the event, you can get one anniversary specific mic frame (3 days) if you send others any of the four anniversary gifts.",
                            "This list is for female users only.",
                            "After the event, the top three on the list will receive personalized medal (customized) and other rich rewards. (for personalized medal: winners can choose five characters from 26 English letters and 10 Arabic numerals as their own custom-made copywriting)",
                            "During the event, users will increase their charm value by receiving anniversary gifts. 1 gold coin = 1 charm value, and the higher the charm value is, the higher the ranking will be.",
                            "The rewards will be distributed within 1-3 days after the activity.",
                        ],
                    },
                    // 财富榜
                    {
                        list:[
                            "Activity duration: 11:00 a.m., July 1, 2019 - 23:59 p.m., July 31, 2019",
                            "During the event, you can get one anniversary specific mic frame (3 days) if you send others any of the four anniversary gifts.",
                            "After the event, the top three on the list will receive personalized medal (customized) and other rich rewards. (for personalized medal: winners can choose five characters from 26 English letters and 10 Arabic numerals as their own custom-made copywriting)",
                            "During the event, users will increase their charm value by receiving anniversary gifts. 1 gold coin = 1 charm value, and the higher the charm value is, the higher the ranking will be.",
                            "The rewards will be distributed within 1-3 days after the activity.",
                            "After activity, our official customer service staff will contact with users to get relevant activity rewards. It will be deemed as giving up rewards without any response within 1 month.",
                            "If we found out any malicious way to obtain rewards during the event, once verified, the user will be disqualified and rewards will be cancelled too.",
                        ],
                    },
                    // 房间榜
                    {
                        list:[
                            "Activity duration: 11:00 a.m., July 1, 2019 - 23:59 p.m., July 31, 2019",
                            "During the event, users will increase the value of the room by sending out any gifts in it. 1 gold coin = 1 value, and the higher the value of the room is, the higher its ranking will be.",
                            "The rewards will be distributed within 1-3 days after the activity.",
                            "After activity, our official customer service staff will contact with users to get relevant activity rewards. It will be deemed as giving up rewards without any response within 1 month.",
                            "If we found out any malicious way to obtain rewards during the event, once verified, the user will be disqualified and rewards will be cancelled too.",
                        ],
                    },
                     // cp榜
                    {
                        list:[
                            "Activity duration: 11:00 a.m., July 1, 2019 - 23:59 p.m., July 31, 2019",
                            "During the event, the two users who send each other the most gold coins by gifts will make up a CP, and 1 gold coin = 1 CP value.",
                            "The CP List will rank CPs from high to low according to the sum of gold coins by gifts (converted into the CP value) that the paired users send to each other. The greater the sum is, the higher the ranking will be.",
                            "After activity, our official customer service staff will contact with users to get relevant activity rewards. It will be deemed as giving up rewards without any response within 1 month.",
                            "If we found out any malicious way to obtain rewards during the event, once verified, the user will be disqualified and rewards will be cancelled too.",
                        ],
                    }
                ],
                anniversary_rewads:'During the event, you can get one anniversary specific mic frame (3 days) if you send others any of the four anniversary gifts. ',
                anniversary_img:'',
                copyright:'All the rights of this event belongs to Haya official administrators',
                apple_copyright:'Apple is not a sponsor and its not involved in any way with the contests nor has it received any gifts from any activity.',
            }
        ],
       
    },
    created:function(){
        document.title=this.list[this.lang].title
    },
    methods:{
        //打开弹窗
        showPop:function (type) {
            this.top = window.pageYOffset;
            this.top_num = -window.pageYOffset/(parseFloat(document.documentElement.style.fontSize));
            this.pop = type;
        },
        //关闭弹窗
        closePop:function () {
            this.pop = false;
            var that = this;
            this.$nextTick(function () {
                console.log(window.pageYOffset);
                window.scrollTo(0,that.top)
            });
        },
        // 切换选项
        changeTap:function(index){
            this.cur_active=index;
           
        },
        // 查看更多排名
        moreRank:function(){

        }
    }
})
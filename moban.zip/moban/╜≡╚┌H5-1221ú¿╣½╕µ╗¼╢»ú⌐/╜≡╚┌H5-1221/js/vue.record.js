/**
 * Created by Administrator on 2018/12/21 0021.
 */
var vm = new Vue({
    el:'.vueBox',
    data:{
        record_list:[
            {
                title:'获得金币',
                source:'转盘',
                time:'2018-04-25 12:23',
                num:'1',
                icon:'images/1.png',
                explain:0
            },
            {
                title:'获得金币',
                source:'转盘',
                time:'2018-04-25 12:23',
                num:'10',
                icon:'images/1.png',
                explain:0
            },
            {
                title:'获得低息贷款产品',
                source:'转盘',
                time:'2018-04-25 12:23',
                num:'1',
                icon:'images/2.png',
                explain:0
            },
            {
                title:'获得5折查征信',
                source:'转盘',
                time:'2018-04-25 12:23',
                num:'1',
                icon:'images/3.png',
                explain:0
            },
            {
                title:'获得iPhone XS 64G',
                source:'转盘',
                time:'2018-04-25 12:23',
                num:'1',
                icon:'images/4.png',
                explain:1
            },
            {
                title:'获得100元现金红包',
                source:'转盘',
                time:'2018-04-25 12:23',
                num:'1',
                icon:'images/5.png',
                explain:1
            }
        ]
    }
});
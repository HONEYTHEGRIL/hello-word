/**
 * Created by Administrator on 2018/12/21 0021.
 */
var vm = new Vue({
    el:'.vueBox',
    data:{
        //控制弹窗
        show_tip:false,
        //控制公告
        animate:false,
        // 公告内容
        notice_list:[
            '恭喜夏**完成一笔现金提现到账',
            '恭喜*国*完成一笔现金提现到账',
            '恭喜**常完成一笔现金提现到账'
        ],
        //邀请码
        invite_code:'23R9HF',
        // 邀请老铁流程
        flow_list:[
            '点击按钮进行分享给好友',
            '获取额度',
            '最快一小时到账'
        ],
        invite_list:[
            '1.邀请亲朋好友、同学及同事成功率最高',
            '2.分享到3个及以上的微信群、QQ群，成功邀请的几率会提升200%哦~',
            '3.可以告诉您的朋友，注册成功即可领6元以上的大红包'
        ],
        // 老铁列表
        fans_list:[
            {
                header:'',
                name:'用户昵称',
                time:'2018-05-05 11:07:24',
                money:'+2.00',
                type:'收益'
            },
            {
                header:'',
                name:'用户昵称',
                time:'2018-05-05 11:07:24',
                money:'+2.00',
                type:'收益'
            },
            {
                header:'',
                name:'用户昵称',
                time:'2018-05-05 11:07:24',
                money:'+2.00',
                type:'收益'
            },
            {
                header:'',
                name:'用户昵称',
                time:'2018-05-05 11:07:24',
                money:'+2.00',
                type:'收益'
            },
            {
                header:'',
                name:'用户昵称',
                time:'2018-05-05 11:07:24',
                money:'+2.00',
                type:'收益'
            },
            {
                header:'',
                name:'用户昵称',
                time:'2018-05-05 11:07:24',
                money:'+2.00',
                type:'收益'
            },
            {
                header:'',
                name:'用户昵称',
                time:'2018-05-05 11:07:24',
                money:'+2.00',
                type:'收益'
            },
            {
                header:'',
                name:'用户昵称',
                time:'2018-05-05 11:07:24',
                money:'+2.00',
                type:'收益'
            },
            {
                header:'',
                name:'用户昵称',
                time:'2018-05-05 11:07:24',
                money:'+2.00',
                type:'收益'
            }

        ]
    },
    created:function () {
        setInterval(this.roll,2000)
    },
    methods:{
        roll:function () {
            this.animate = true;
            setTimeout(() => {
                this.notice_list.push(this.notice_list[0]);
                this.notice_list.shift();
                this.animate = false;
            }, 500)
        },
        copy_code:function () {
            var invite_code = document.getElementsByClassName("copy_there")[0];
            invite_code.select();
            document.execCommand("copy");
            this.show_tip=true;
            let that= this;
            setTimeout(function () {
                that.show_tip=false
            },1000)
        }
    }
});
/**
 * Created by Administrator on 2018/12/21 0021.
 */
var vm = new Vue({
    el:'.vueBox',
    data:{
        //切换列表
        cur_index:0,
        //控制公告
        animate:false,
        // 公告内容
        notice_list:[
            '恭喜夏**完成一笔现金提现到账',
            '恭喜*国*完成一笔现金提现到账',
            '恭喜**常完成一笔现金提现到账'
        ],
        //今日汇率
        rate:0.8,
        // 余额
        balance:'80.00',
        //累计收益
        earnings:8.03,
        //金币记录
        gold_list:[
            {
                title:'签到积分',
                time:'2018-05-05 11:07:24',
                num:'13.25'
            },
            {
                title:'签到积分',
                time:'2018-05-05 11:07:24',
                num:'13.25'
            },
            {
                title:'低息贷款',
                time:'2018-05-05 11:07:24',
                num:'13.25'
            },
            {
                title:'签到积分',
                time:'2018-05-05 11:07:24',
                num:'13.25'
            },
            {
                title:'签到积分',
                time:'2018-05-05 11:07:24',
                num:'13.25'
            },
            {
                title:'签到积分',
                time:'2018-05-05 11:07:24',
                num:'13.25'
            },
            {
                title:'低息贷款',
                time:'2018-05-05 11:07:24',
                num:'13.25'
            },
            {
                title:'签到积分',
                time:'2018-05-05 11:07:24',
                num:'13.25'
            },
            {
                title:'签到积分',
                time:'2018-05-05 11:07:24',
                num:'13.25'
            },
            {
                title:'签到积分',
                time:'2018-05-05 11:07:24',
                num:'13.25'
            },
            {
                title:'低息贷款',
                time:'2018-05-05 11:07:24',
                num:'13.25'
            },
            {
                title:'签到积分',
                time:'2018-05-05 11:07:24',
                num:'13.25'
            }
        ],
        //零钱记录
        cash_list:[
            {
                title:'签到积分',
                time:'2018-05-05 11:07:24',
                num:'13.25'
            },
            {
                title:'签到积分',
                time:'2018-05-05 11:07:24',
                num:'13.25'
            },
            {
                title:'低息贷款',
                time:'2018-05-05 11:07:24',
                num:'13.25'
            },
            {
                title:'签到积分',
                time:'2018-05-05 11:07:24',
                num:'13.25'
            },
            {
                title:'签到积分',
                time:'2018-05-05 11:07:24',
                num:'13.25'
            }
        ]
    },
    created:function () {
        setInterval(this.roll,2000)
    },
    methods:{
        roll:function () {
            this.animate = true;
            setTimeout(() => {
                this.notice_list.push(this.notice_list[0]);
                this.notice_list.shift();
                this.animate = false;
            }, 500)
        },
        changeList:function (index) {
            this.cur_index=index;
        }
    }
});
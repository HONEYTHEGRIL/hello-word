/**
 * Created by Administrator on 2019/2/27 0027.
 */
var vm = new Vue({
    el:'.vueBox',
    data:{

        pop:false,

        current_time:1550455200000,
        start_time:1550628000000,
        //剩余时间

        hr:'',
        min:'',
        sec:'',


        foreword_list:[
            {
                text:'折扣先行，福利不停'
            },
            {
                text:'购买',
                font:'指定头饰、座驾、CP家园'
            },
            {
                text:'即可享受超值折扣'
            }
        ],

        head_wear_list:[
            {
                icon:'',
                name:'小王冠',
                ruling_price:'66',//现价
                original_price:'99',//原价
                discount:'6.6'//折扣
            },
            {
                icon:'',
                name:'天使翅膀',
                ruling_price:'99',//现价
                original_price:'199',//原价
                discount:'5'//折扣
            },
            {
                icon:'',
                name:'风车',
                ruling_price:'179',//现价
                original_price:'298',//原价
                discount:'6'//折扣
            },
            {
                icon:'',
                name:'粉红宝石',
                ruling_price:'199',//现价
                original_price:'399',//原价
                discount:'5'//折扣
            }
        ],

        car_list:[
            {
                icon:'',
                name:'小马驹',
                ruling_price:'1999',//现价
                original_price:'3999',//原价
                discount:'6.6'//折扣
            },
            {
                icon:'',
                name:'兰博基尼',
                ruling_price:'199',//现价
                original_price:'399',//原价
                discount:'5'//折扣
            },
            {
                icon:'',
                name:'猎影',
                ruling_price:'199',//现价
                original_price:'399',//原价
                discount:'6'//折扣
            },
            {
                icon:'',
                name:'周年座驾-Hi仔',
                ruling_price:'199',//现价
                original_price:'399',//原价
                discount:'5'//折扣
            }
        ],

        rules_list:[
            {
                spe_text:'活动时间',
                highlight:'2019年3月18日11:00-2019年3月25日11:00'
            },
            {
                text:'活动期间，购买，',
                highlight:'指定头饰、座驾、CP房',
                font:'将获得一定折扣；'
            },
            {
                text:'购买还在有效期内的头饰、座驾，将会累计有效时长；'
            },
            {
                text:'折扣价格将在活动结束后恢复为原价；'
            },
            {
                text:'购买CP家园需先结成CP后，在CP房内进行购买；'
            }
        ],

        copyright:[
            '本活动与苹果公司无关',
            '- 官方团队保留在法律范围内对上述规则进行解释的权利 -',
            '本活动若出现非正当方式获取奖励的行为，一经查实将取消活动资格和待发奖励，情节严重者将被追究法律责任。'
        ],
        //分享渠道
        share_list:[
            {
                icon:'images/wechart_icon.png',
                text:'微信'
            },
            {
                icon:'images/friends_icon.png',
                text:'朋友圈'
            },
            {
                icon:'images/microblog_icon.png',
                text:'微博'
            },
            {
                icon:'images/qq_icon.png',
                text:'QQ好友'
            },
            {
                icon:'images/space_icon.png',
                text:'空间'
            }
        ]
    },
    created: function () {

        var total_micro_second =  this.start_time - this.current_time;
        countdown(this,total_micro_second);//调用倒计时
    },
    methods:{
        showPop:function () {
            this.pop = true
        },
        closePop:function () {
            this.pop = false
        },
        share:function (index) {
            console.log(this.share_list[index].text);
            this.pop = false;
            //调用截图方法
            setTimeout(() => {
                screenshotsImg();
        }, 1000);
            console.log('2');
        }
    }

});

//  封装截图方法
function screenshotsImg(){
    // document.getElementById('ico_tips').style.visibility='hidden'
    // document.getElementById('screenshots').style.backgroundColor='transparent'
    // document.getElementById('screenshots').style.boxShadow='none'
    html2canvas(document.querySelector("#screenshots"),{
        backgroundColor: 'transparent',// 设置背景透明
    }).then(canvas => {
        // document.body.appendChild(canvas)
        canvasTurnImg(canvas)
    });
}

//转换png图片
function canvasTurnImg(canvas){
    // 图片导出为 png 格式
    var type = 'png';
    var imgData = canvas.toDataURL(type);
    /**
     * 获取mimeType
     * @param  {String} type the old mime-type
     * @return the new mime-type
     */
    var _fixType = function(type) {
        type = type.toLowerCase().replace(/jpg/i, 'jpeg');
        var r = type.match(/png|jpeg|bmp|gif/)[0];
        return 'image/' + r;
    };

    // 加工image data，替换mime type
    imgData = imgData.replace(_fixType(type),'image/octet-stream');

    /**
     * 在本地进行文件保存
     * @param  {String} data     要保存到本地的图片数据
     * @param  {String} filename 文件名
     */
    var saveFile = function(data, filename){
        var save_link = document.createElementNS('http://www.w3.org/1999/xhtml', 'a');
        save_link.href = data;
        save_link.download = filename;

        var event = document.createEvent('MouseEvents');
        event.initMouseEvent('click', true, false, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);
        save_link.dispatchEvent(event);
    };

    // 下载后的文件名
    var filename = 'screenshots_card_' + (new Date()).getTime() + '.' + type;
    // download
    saveFile(imgData,filename);
    // console.log(filename)

}